<script setup>
import { Head, Link, useForm, router, usePage } from '@inertiajs/vue3';
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import { ref, computed, watch } from 'vue';

const props = defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
    laravelVersion: String,
    phpVersion: String,
    featuredBlogs: { type: Array, default: () => [] },
    locations: { type: Array, default: () => [] },
    diseases: { type: Array, default: () => [] },
    services: { type: Array, default: () => [] },
    hospitals: { type: Array, default: () => [] },
    reviews: { type: Array, default: () => [] },
});

const searchQuery = ref('');
const searchResults = ref(null);
const searchLoading = ref(false);
const showSearchDropdown = ref(false);
let searchTimeout = null;

watch(searchQuery, (val) => {
    clearTimeout(searchTimeout);
    if (val.length < 2) { searchResults.value = null; showSearchDropdown.value = false; return; }
    searchLoading.value = true;
    searchTimeout = setTimeout(async () => {
        try {
            const res = await fetch(`/api/search?q=${encodeURIComponent(val)}`);
            searchResults.value = await res.json();
            showSearchDropdown.value = true;
        } catch (e) { console.error(e); }
        searchLoading.value = false;
    }, 300);
});

const goToPage = (url) => {
    showSearchDropdown.value = false;
    searchQuery.value = '';
    router.visit(url);
};

const selectedLocation = ref('');
const selectedHospital = ref('');

const filteredBlogs = computed(() => {
    let blogs = props.featuredBlogs;
    
    if (selectedLocation.value) {
        const loc = props.locations.find(l => l.id == selectedLocation.value);
        if (loc) {
            blogs = blogs.filter(b => b.location === loc.name);
        }
    }
    
    if (selectedHospital.value) {
        const hosp = props.hospitals.find(h => h.id == selectedHospital.value);
        if (hosp) {
            const locName = hosp.location ? hosp.location.name : null;
            blogs = blogs.filter(b => {
                if (b.hospital_id == hosp.id) return true;
                if (!b.hospital_id && locName && b.location === locName) return true;
                return false;
            });
        }
    }
    
    return blogs;
});

const activeTab = ref('all');
const displayBlogs = computed(() => {
    let blogs = filteredBlogs.value;
    if (activeTab.value === 'service') return blogs.filter(b => b.type === 'service');
    if (activeTab.value === 'disease') return blogs.filter(b => b.type === 'disease');
    return blogs;
});

const page = usePage();

const form = useForm({
    name: '',
    phone: '',
    source_url: page.props.current_url || '',
});

const submit = () => {
    form.post(route('admin.leads.store'), {
        preserveScroll: true,
        onSuccess: () => {
            form.reset('name', 'phone');
            alert('Thank you! Our care team will contact you shortly.');
        }
    });
};

const cityLocations = computed(() => props.locations.filter(l => l.type === 'city'));
</script>

<template>
    <Head title="Premium Eye Care — Blink Eye Hospitals" />

    <div class="min-h-screen bg-slate-950 font-sans text-white selection:bg-teal-500 selection:text-white">

        <!-- ═══════ HEADER ═══════ -->
        <header class="fixed w-full top-0 z-50 bg-slate-950/70 backdrop-blur-2xl border-b border-white/5">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                <Link href="/" class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="white" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-teal-300 to-cyan-300 bg-clip-text text-transparent">Blink Eye</span>
                </Link>
                <div class="flex items-center gap-5">
                    <a href="tel:1800-123-4567" class="hidden sm:flex items-center gap-2 text-slate-400 font-medium hover:text-teal-400 transition-colors text-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="size-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-2.896-1.596-5.48-4.18-7.076-7.076l1.293-.97c.362-.271.527-.733.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z" /></svg>
                        1800-123-4567
                    </a>
                    <Link :href="route('login')" class="text-sm font-semibold text-slate-300 hover:text-teal-400 transition-colors">Admin Login</Link>
                    <Link :href="route('appointment.create')" class="rounded-full px-5 py-2 bg-gradient-to-r from-teal-500 to-cyan-500 text-white font-semibold hover:from-teal-400 hover:to-cyan-400 transition-all text-sm shadow-lg shadow-teal-500/20">
                        Book Appointment
                    </Link>
                </div>
            </div>
        </header>

        <!-- ═══════ HERO ═══════ -->
        <section class="relative pt-32 pb-20 lg:pt-44 lg:pb-28 overflow-hidden">
            <div class="absolute inset-0 z-0">
                <div class="absolute top-0 right-0 -translate-y-12 translate-x-1/4 w-[500px] h-[500px] rounded-full bg-teal-500/15 blur-[120px] animate-float"></div>
                <div class="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[400px] h-[400px] rounded-full bg-cyan-500/10 blur-[100px] animate-float-delayed"></div>
                <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-blue-500/8 blur-[80px] animate-float"></div>
            </div>

            <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-3xl mx-auto mb-12">
                    <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-300 text-xs font-semibold uppercase tracking-wider mb-6">
                        <span class="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse"></span>
                        {{ $page.props.currentHospital ? $page.props.currentHospital.name : 'World-Class Eye Care' }}
                    </span>
                    <h1 class="text-4xl sm:text-5xl lg:text-7xl font-extrabold tracking-tight mb-6 leading-[1.1]">
                        Find the Best
                        <span class="bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent"> Eye Treatment</span>
                        <br class="hidden sm:block"/>Near You
                    </h1>
                    <p class="text-lg text-slate-400 mb-10 max-w-2xl mx-auto">Search for any eye disease, treatment or location to find expert care, top hospitals, and detailed guides — all personalized to your area.</p>
                </div>

                <!-- Search Bar -->
                <div class="max-w-2xl mx-auto relative">
                    <div class="relative group">
                        <div class="absolute -inset-[2px] bg-gradient-to-r from-teal-500 via-cyan-500 to-blue-500 rounded-2xl opacity-40 group-hover:opacity-70 blur-sm transition duration-500"></div>
                        <div class="relative flex items-center bg-slate-900 rounded-2xl border border-white/10 overflow-hidden">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5 text-slate-500 ml-5 flex-shrink-0"><path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" /></svg>
                            <input v-model="searchQuery" type="text" placeholder='Search "Cataract Surgery in Bathinda" or "Glaucoma"...' class="flex-1 py-4 px-4 text-base text-white placeholder-slate-500 border-0 focus:ring-0 focus:outline-none bg-transparent" @focus="searchQuery.length >= 2 && (showSearchDropdown = true)" @blur="setTimeout(() => showSearchDropdown = false, 200)" />
                            <div v-if="searchLoading" class="mr-4">
                                <div class="w-5 h-5 border-2 border-teal-400 border-t-transparent rounded-full animate-spin"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Search Dropdown -->
                    <div v-if="showSearchDropdown && searchResults" class="absolute top-full left-0 right-0 mt-2 bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/10 z-50 max-h-96 overflow-y-auto">
                        <div v-if="searchResults.pages && searchResults.pages.length > 0" class="p-4">
                            <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 px-2">Suggested Pages</p>
                            <button v-for="page in searchResults.pages.slice(0, 6)" :key="page.url" @mousedown.prevent="goToPage(page.url)" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-teal-500/10 transition-colors text-left group">
                                <div class="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 19.5 15-15m0 0H8.25m11.25 0v11.25" /></svg>
                                </div>
                                <span class="text-sm font-medium text-slate-300">{{ page.title }}</span>
                            </button>
                        </div>
                        <div v-if="searchResults.results" class="border-t border-white/5 p-4">
                            <div v-if="searchResults.results.diseases && searchResults.results.diseases.length > 0" class="mb-3">
                                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-2">Diseases</p>
                                <button v-for="d in searchResults.results.diseases" :key="d.id" @mousedown.prevent="searchQuery = d.name" class="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/5 text-sm text-slate-400">
                                    <img v-if="d.image" :src="`/storage/${d.image}`" :alt="d.name" class="w-8 h-8 rounded-lg object-cover flex-shrink-0" />
                                    <span v-else class="w-8 h-8 rounded-lg bg-rose-500/20 flex items-center justify-center flex-shrink-0"><span class="w-2 h-2 rounded-full bg-rose-400"></span></span>
                                    {{ d.name }}
                                </button>
                            </div>
                            <div v-if="searchResults.results.services && searchResults.results.services.length > 0" class="mb-3">
                                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-2">Services</p>
                                <button v-for="s in searchResults.results.services" :key="s.id" @mousedown.prevent="searchQuery = s.name" class="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/5 text-sm text-slate-400">
                                    <img v-if="s.image" :src="`/storage/${s.image}`" :alt="s.name" class="w-8 h-8 rounded-lg object-cover flex-shrink-0" />
                                    <span v-else class="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0"><span class="w-2 h-2 rounded-full bg-cyan-400"></span></span>
                                    {{ s.name }}
                                </button>
                            </div>
                            <div v-if="searchResults.results.hospitals && searchResults.results.hospitals.length > 0">
                                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-2">Hospitals</p>
                                <button v-for="h in searchResults.results.hospitals" :key="h.id" @mousedown.prevent="searchQuery = h.name" class="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/5 text-sm text-slate-400">
                                    <img v-if="h.image" :src="`/storage/${h.image}`" :alt="h.name" class="w-8 h-8 rounded-lg object-cover flex-shrink-0" />
                                    <span v-else class="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center flex-shrink-0"><span class="w-2 h-2 rounded-full bg-emerald-400"></span></span>
                                    {{ h.name }}
                                </button>
                            </div>
                        </div>
                        <div v-if="(!searchResults.pages || searchResults.pages.length === 0) && (!searchResults.results || (!searchResults.results.diseases?.length && !searchResults.results.services?.length))" class="p-6 text-center text-slate-500 text-sm">No results found. Try a different search term.</div>
                    </div>
                </div>

                <div class="mt-8 text-center flex flex-col items-center justify-center gap-3">
                    <div class="text-slate-500 text-sm font-medium">— OR —</div>
                    <Link :href="route('appointment.create')" class="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-white font-bold rounded-2xl shadow-xl shadow-teal-500/20 transition-all glow-btn">
                        Book Appointment Directly
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" /></svg>
                    </Link>
                </div>

                <!-- Location Chips -->
                <div v-if="cityLocations.length > 0" class="flex flex-wrap items-center justify-center gap-2 mt-8 max-w-2xl mx-auto">
                    <span class="text-xs font-semibold text-slate-600 uppercase tracking-wider mr-2">Popular:</span>
                    <button v-for="loc in cityLocations" :key="loc.id" @click="searchQuery = loc.name" class="px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm font-medium text-slate-400 hover:border-teal-500/50 hover:bg-teal-500/10 hover:text-teal-300 transition-all">{{ loc.name }}</button>
                </div>
            </div>
        </section>

        <!-- ═══════ STATS ═══════ -->
        <section class="py-16 relative">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                    <div v-for="(stat, i) in [{num:'50,000+',label:'Successful Surgeries',icon:'✦'},{num:'15+',label:'Hospital Locations',icon:'◎'},{num:'98%',label:'Success Rate',icon:'◈'},{num:'25+',label:'Years Experience',icon:'◇'}]" :key="i" class="group relative">
                        <div class="absolute -inset-[1px] bg-gradient-to-b from-teal-500/20 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition duration-500"></div>
                        <div class="relative bg-white/[0.03] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-6 text-center hover:bg-white/[0.06] transition-all duration-300">
                            <div class="text-2xl mb-2 opacity-60">{{ stat.icon }}</div>
                            <div class="text-3xl md:text-4xl font-extrabold bg-gradient-to-r from-teal-300 to-cyan-300 bg-clip-text text-transparent mb-1">{{ stat.num }}</div>
                            <div class="text-xs text-slate-500 font-medium uppercase tracking-wider">{{ stat.label }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ═══════ SPECIALIZATIONS ═══════ -->
        <section class="py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-3xl mx-auto mb-14">
                    <h2 class="text-3xl font-extrabold sm:text-4xl">Our <span class="bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">Specializations</span></h2>
                    <p class="mt-4 text-lg text-slate-500">From routine checkups to advanced surgical solutions — we treat every eye condition.</p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-14">
                    <div>
                        <h3 class="text-sm font-semibold text-rose-400 uppercase tracking-wider mb-5 flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-rose-400"></span>Eye Conditions We Treat
                        </h3>
                        <div class="space-y-3">
                            <div v-for="disease in diseases" :key="disease.id" @click="searchQuery = disease.name; typeof window !== 'undefined' && window.scrollTo({top: 0, behavior: 'smooth'})" class="group p-5 rounded-2xl bg-white/[0.03] border border-white/[0.06] hover:border-rose-500/30 hover:bg-rose-500/5 transition-all cursor-pointer flex gap-4 items-start">
                                <img v-if="disease.image" :src="`/storage/${disease.image}`" :alt="disease.name" class="w-16 h-16 rounded-xl object-cover flex-shrink-0 ring-1 ring-white/10 group-hover:ring-rose-500/30 transition-all" />
                                <div class="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center flex-shrink-0" v-else>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
                                </div>
                                <div>
                                    <h4 class="font-bold text-slate-200 group-hover:text-rose-300 transition-colors">{{ disease.name }}</h4>
                                    <p class="text-sm text-slate-500 mt-1 line-clamp-2">{{ disease.description || 'Learn more about this condition and available treatments.' }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-5 flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-cyan-400"></span>Treatments & Services
                        </h3>
                        <div class="space-y-3">
                            <div v-for="service in services" :key="service.id" @click="searchQuery = service.name; typeof window !== 'undefined' && window.scrollTo({top: 0, behavior: 'smooth'})" class="group p-5 rounded-2xl bg-white/[0.03] border border-white/[0.06] hover:border-cyan-500/30 hover:bg-cyan-500/5 transition-all cursor-pointer flex gap-4 items-start">
                                <img v-if="service.image" :src="`/storage/${service.image}`" :alt="service.name" class="w-16 h-16 rounded-xl object-cover flex-shrink-0 ring-1 ring-white/10 group-hover:ring-cyan-500/30 transition-all" />
                                <div class="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center flex-shrink-0" v-else>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 1 1-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 0 0 4.486-6.336l-3.276 3.277a3.004 3.004 0 0 1-2.25-2.25l3.276-3.276a4.5 4.5 0 0 0-6.336 4.486c.049.58.025 1.193-.14 1.743" /></svg>
                                </div>
                                <div>
                                    <h4 class="font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">{{ service.name }}</h4>
                                    <p class="text-sm text-slate-500 mt-1 line-clamp-2">{{ service.description || 'Expert surgical and diagnostic eye care services.' }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ═══════ BLOG GRID ═══════ -->
        <section class="py-20 bg-slate-900/50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
                    <div>
                        <h2 class="text-3xl font-extrabold">Explore Expert <span class="bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">Guides</span></h2>
                        <p class="mt-2 text-slate-500">Localized treatment information and hospital recommendations.</p>
                    </div>
                    <div class="flex gap-4">
                        <select v-model="selectedLocation" class="rounded-xl border-white/10 bg-white/5 text-sm py-2.5 px-4 text-slate-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 min-w-[160px]">
                            <option value="">All Locations</option>
                            <option v-for="loc in cityLocations" :key="loc.id" :value="loc.id">{{ loc.name }}</option>
                        </select>
                        <select v-model="selectedHospital" class="rounded-xl border-white/10 bg-white/5 text-sm py-2.5 px-4 text-slate-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 min-w-[160px]">
                            <option value="">All Hospitals</option>
                            <option v-for="hospital in hospitals" :key="hospital.id" :value="hospital.id">{{ hospital.name }}</option>
                        </select>
                    </div>
                </div>
                <div class="flex gap-2 mb-8">
                    <button @click="activeTab = 'all'" :class="[activeTab === 'all' ? 'bg-white/10 text-white border-white/20' : 'text-slate-500 border-white/5 hover:bg-white/5', 'px-5 py-2 rounded-full text-sm font-semibold transition-all border']">All</button>
                    <button @click="activeTab = 'service'" :class="[activeTab === 'service' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' : 'text-slate-500 border-white/5 hover:bg-white/5', 'px-5 py-2 rounded-full text-sm font-semibold transition-all border']">Services</button>
                    <button @click="activeTab = 'disease'" :class="[activeTab === 'disease' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' : 'text-slate-500 border-white/5 hover:bg-white/5', 'px-5 py-2 rounded-full text-sm font-semibold transition-all border']">Diseases</button>
                </div>
                <div v-if="displayBlogs.length > 0" class="flex overflow-x-auto gap-6 pb-8 snap-x snap-mandatory hide-scroll-bar -mx-4 px-4 sm:mx-0 sm:px-0">
                    <Link v-for="(blog, index) in displayBlogs" :key="index" :href="blog.url" class="group block w-[85vw] sm:w-[350px] flex-shrink-0 snap-start">
                        <div class="h-full flex flex-col bg-white/[0.03] rounded-2xl p-7 border border-white/[0.06] hover:border-teal-500/30 hover:bg-white/[0.06] transition-all duration-300">
                            <div class="flex items-center gap-3 mb-4">
                                <div :class="[blog.type === 'service' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-rose-500/20 text-rose-400', 'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform']">
                                    <svg v-if="blog.type === 'service'" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 1 1-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 0 0 4.486-6.336l-3.276 3.277a3.004 3.004 0 0 1-2.25-2.25l3.276-3.276a4.5 4.5 0 0 0-6.336 4.486c.049.58.025 1.193-.14 1.743" /></svg>
                                    <svg v-else xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
                                </div>
                                <span v-if="blog.location" class="text-xs font-medium text-slate-500 bg-white/5 px-2 py-0.5 rounded-full">📍 {{ blog.location }}</span>
                            </div>
                            <h3 class="text-base font-bold text-slate-200 mb-2 group-hover:text-teal-300 transition-colors leading-snug">{{ blog.title }}</h3>
                            <p class="text-slate-500 text-sm mt-auto font-medium flex items-center gap-1 group-hover:text-teal-400 transition-colors pt-3">
                                Read Guide
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4 group-hover:translate-x-1 transition-transform"><path fill-rule="evenodd" d="M3 10a.75.75 0 0 1 .75-.75h10.638L10.23 5.29a.75.75 0 1 1 1.04-1.08l5.5 5.25a.75.75 0 0 1 0 1.08l-5.5 5.25a.75.75 0 1 1-1.04-1.08l4.158-3.96H3.75A.75.75 0 0 1 3 10Z" clip-rule="evenodd" /></svg>
                            </p>
                        </div>
                    </Link>
                </div>
                <div v-else class="text-center py-16 text-slate-500">
                    <p class="text-lg">No guides available for this filter.</p>
                    <p class="text-sm mt-1">Try selecting a different location or category.</p>
                </div>
            </div>
        </section>

        <!-- ═══════ HOSPITALS ═══════ -->
        <section v-if="hospitals.length > 0" class="py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-3xl mx-auto mb-14">
                    <h2 class="text-3xl font-extrabold sm:text-4xl">Our Hospital <span class="bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">Network</span></h2>
                    <p class="mt-4 text-lg text-slate-500">Find the Blink Eye branch closest to you.</p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div v-for="hospital in hospitals" :key="hospital.id" class="group relative">
                        <div class="absolute -inset-[1px] bg-gradient-to-r from-teal-500/30 to-cyan-500/30 rounded-2xl opacity-0 group-hover:opacity-100 transition duration-500 blur-sm"></div>
                        <div class="relative bg-white/[0.03] backdrop-blur-sm rounded-2xl border border-white/[0.06] hover:bg-white/[0.06] transition-all duration-300 overflow-hidden">
                            <a :href="'/' + hospital.slug" target="_blank" v-if="hospital.image" class="h-44 w-full block">
                                <img :src="`/storage/${hospital.image}`" :alt="hospital.name" class="w-full h-full object-cover" />
                            </a>
                            <div class="p-8">
                                <div v-if="!hospital.image" class="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center mb-5">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 7.5h.008v.008h-.008v-.008Zm0 3h.008v.008h-.008v-.008Zm0 3h.008v.008h-.008v-.008Z" /></svg>
                                </div>
                                <a :href="'/' + hospital.slug" target="_blank" class="block group/title">
                                    <h3 class="text-xl font-bold text-white mb-1 group-hover/title:text-teal-400 transition-colors">{{ hospital.name }}</h3>
                                </a>
                                <p class="text-sm text-slate-500 mb-4">{{ hospital.location ? hospital.location.name : 'Location TBD' }}</p>
                                <div class="space-y-2 text-sm text-slate-400">
                                    <a v-if="hospital.phone" :href="'tel:' + hospital.phone" class="flex items-center gap-2 hover:text-teal-400 transition-colors">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 flex-shrink-0"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-2.896-1.596-5.48-4.18-7.076-7.076l1.293-.97c.362-.271.527-.733.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z" /></svg>
                                        {{ hospital.phone }}
                                    </a>
                                    <a v-if="hospital.email" :href="'mailto:' + hospital.email" class="flex items-center gap-2 hover:text-teal-400 transition-colors">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 flex-shrink-0"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" /></svg>
                                        {{ hospital.email }}
                                    </a>
                                </div>
                                <div class="mt-6 pt-5 border-t border-white/5 space-y-3">
                                    <a :href="'/' + hospital.slug" target="_blank" class="block w-full text-center px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white font-bold hover:from-teal-400 hover:to-cyan-400 transition-all shadow-lg shadow-teal-500/10">
                                        Visit Hospital
                                    </a>
                                    <Link :href="route('appointment.create', { hospital_id: hospital.id })" class="block w-full text-center px-4 py-2.5 rounded-xl bg-teal-500/10 text-teal-400 font-semibold hover:bg-teal-500 hover:text-white transition-all border border-teal-500/20 hover:border-teal-500">
                                        Book at This Location
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ═══════ FEATURES ═══════ -->
        <section class="py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                    <div v-for="(feat, i) in [{title:'Expert Surgeons',desc:'Board-certified specialists with decades of experience in complex eye procedures.',color:'teal'},{title:'Advanced Technology',desc:'Equipped with the latest laser and robotic systems for unmatched precision.',color:'cyan'},{title:'Compassionate Care',desc:'Patient-first approach ensuring comfort and peace of mind at every step.',color:'rose'}]" :key="i" class="group">
                        <div class="relative bg-white/[0.03] rounded-2xl p-8 border border-white/[0.06] hover:bg-white/[0.06] transition-all duration-300">
                            <div :class="['mx-auto w-16 h-16 rounded-2xl flex items-center justify-center mb-5 transition-transform group-hover:scale-110', feat.color === 'teal' ? 'bg-teal-500/20 text-teal-400' : feat.color === 'cyan' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-rose-500/20 text-rose-400']">
                                <svg v-if="feat.color==='teal'" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                                <svg v-else-if="feat.color==='cyan'" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" /></svg>
                                <svg v-else xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8"><path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" /></svg>
                            </div>
                            <h3 class="text-xl font-bold text-white mb-2">{{ feat.title }}</h3>
                            <p class="text-slate-500 text-sm">{{ feat.desc }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ═══════ REVIEWS ═══════ -->
        <section v-if="reviews.length > 0" class="py-20 bg-slate-900/40 relative overflow-hidden">
            <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-[120px] pointer-events-none"></div>
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div class="text-center max-w-3xl mx-auto mb-14">
                    <h2 class="text-3xl font-extrabold sm:text-4xl text-white">Patient <span class="bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">Stories</span></h2>
                    <p class="mt-4 text-lg text-slate-400">Real experiences from patients who entrusted us with their vision.</p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div v-for="review in reviews.slice(0, 3)" :key="review.id" class="group relative">
                        <div class="absolute -inset-[1px] bg-gradient-to-r from-teal-500/20 to-cyan-500/20 rounded-3xl opacity-0 group-hover:opacity-100 transition duration-500 blur-sm"></div>
                        <div class="relative bg-white/[0.03] backdrop-blur-xl rounded-3xl p-8 border border-white/[0.06] hover:bg-white/[0.06] transition-all duration-300 flex flex-col h-full">
                            <div class="flex text-amber-400 mb-6 gap-1">
                                <svg v-for="i in review.rating" :key="i" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path fill-rule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z" clip-rule="evenodd" /></svg>
                            </div>
                            <p class="text-slate-300 text-base leading-relaxed mb-8 flex-grow tracking-wide">
                                "{{ review.content }}"
                            </p>
                            <div class="flex items-center gap-4 mt-auto pt-6 border-t border-white/[0.06]">
                                <div class="w-12 h-12 rounded-full bg-gradient-to-br from-teal-500 to-cyan-500 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-teal-500/20 ring-2 ring-white/10">
                                    {{ review.author_name.charAt(0) }}
                                </div>
                                <div>
                                    <h4 class="font-bold text-white text-base">{{ review.author_name }}</h4>
                                    <p class="text-xs font-medium text-slate-500 uppercase tracking-wider">{{ review.source }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ═══════ FOOTER ═══════ -->
        <footer class="border-t border-white/5 pt-12 pb-8">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                    <div>
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="white" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
                            </div>
                            <span class="text-lg font-bold bg-gradient-to-r from-teal-300 to-cyan-300 bg-clip-text text-transparent">Blink Eye</span>
                        </div>
                        <p class="text-sm text-slate-600">Advanced eye care across multiple locations in India. Personalized care, world-class results.</p>
                    </div>
                    <div>
                        <h4 class="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Quick Links</h4>
                        <ul class="space-y-2 text-sm">
                            <li v-for="disease in diseases.slice(0, 4)" :key="disease.id"><button @click="searchQuery = disease.name; typeof window !== 'undefined' && window.scrollTo({top: 0, behavior: 'smooth'})" class="text-slate-600 hover:text-teal-400 transition-colors">{{ disease.name }}</button></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Our Branches</h4>
                        <ul class="space-y-2 text-sm">
                            <li v-for="hospital in hospitals" :key="hospital.id" class="text-slate-600">{{ hospital.name }}</li>
                        </ul>
                    </div>
                </div>
                <div class="border-t border-white/5 pt-8 text-sm text-center text-slate-700">
                    &copy; 2026 Blink Eye Hospitals. All rights reserved.
                </div>
            </div>
        </footer>
    </div>
</template>

<style scoped>
.hide-scroll-bar {
  -ms-overflow-style: none;
  scrollbar-width: none;
}
.hide-scroll-bar::-webkit-scrollbar {
  display: none;
}
@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(30px, -30px) scale(1.05); }
  66% { transform: translate(-20px, 20px) scale(0.95); }
}
.animate-float {
  animation: float 20s ease-in-out infinite;
}
.animate-float-delayed {
  animation: float 25s ease-in-out infinite;
  animation-delay: -5s;
}
.glow-btn {
  position: relative;
}
.glow-btn::after {
  content: '';
  position: absolute;
  inset: -2px;
  background: linear-gradient(135deg, #14b8a6, #06b6d4);
  border-radius: 0.75rem;
  z-index: -1;
  opacity: 0;
  filter: blur(12px);
  transition: opacity 0.3s;
}
.glow-btn:hover::after {
  opacity: 0.6;
}
</style>
