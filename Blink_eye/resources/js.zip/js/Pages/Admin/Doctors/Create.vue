<template>
  <AdminLayout title="Add Doctor">
    <template #header>
      <div class="flex items-center justify-between">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
          Add New Doctor
        </h2>
        <Link :href="route('admin.doctors.index')" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
          Back to Doctors
        </Link>
      </div>
    </template>

    <div class="p-6">
      <div class="max-w-2xl mx-auto bg-white shadow-sm sm:rounded-lg">
        <div class="p-6">
          <form @submit.prevent="submit" enctype="multipart/form-data">
            <div class="space-y-6">
              <div>
                <label for="name" class="block text-sm font-medium text-gray-700">
                  Name <span class="text-red-500">*</span>
                </label>
                <input
                  id="name"
                  v-model="form.name"
                  type="text"
                  class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                <div v-if="errors.name" class="mt-2 text-sm text-red-600">
                  {{ errors.name }}
                </div>
              </div>

              <div>
                <label for="specialty" class="block text-sm font-medium text-gray-700">
                  Specialty
                </label>
                <input
                  id="specialty"
                  v-model="form.specialty"
                  type="text"
                  class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                <div v-if="errors.specialty" class="mt-2 text-sm text-red-600">
                  {{ errors.specialty }}
                </div>
              </div>

              <div>
                <label for="bio" class="block text-sm font-medium text-gray-700">
                  Bio
                </label>
                <textarea
                  id="bio"
                  v-model="form.bio"
                  rows="4"
                  class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                ></textarea>
                <div v-if="errors.bio" class="mt-2 text-sm text-red-600">
                  {{ errors.bio }}
                </div>
              </div>

              <div>
                <label for="hospital_id" class="block text-sm font-medium text-gray-700">
                  Hospital <span class="text-red-500">*</span>
                </label>
                <select
                  id="hospital_id"
                  v-model="form.hospital_id"
                  class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                  <option value="">Select a hospital</option>
                  <option v-for="hospital in hospitals" :key="hospital.id" :value="hospital.id">
                    {{ hospital.name }}
                  </option>
                </select>
                <div v-if="errors.hospital_id" class="mt-2 text-sm text-red-600">
                  {{ errors.hospital_id }}
                </div>
              </div>

              <div>
                <label for="image" class="block text-sm font-medium text-gray-700">
                  Profile Image
                </label>
                <input
                  id="image"
                  type="file"
                  accept="image/*"
                  class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  @change="handleImageChange"
                >
                <div v-if="errors.image" class="mt-2 text-sm text-red-600">
                  {{ errors.image }}
                </div>
              </div>

              <div v-if="form.image_preview" class="mt-4">
                <img :src="form.image_preview" alt="Preview" class="object-cover h-40 w-40 rounded-lg">
              </div>

              <div>
                <label class="flex items-center">
                  <input
                    v-model="form.is_active"
                    type="checkbox"
                    class="text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  >
                  <span class="ml-2 text-sm text-gray-700">Active</span>
                </label>
              </div>
            </div>

            <div class="flex items-center justify-end pt-6 space-x-3">
              <Link :href="route('admin.doctors.index')" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                Cancel
              </Link>
              <button
                type="submit"
                class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
              >
                Save Doctor
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref } from 'vue'
import { router, Link } from '@inertiajs/vue3'
import AdminLayout from '@/Layouts/AdminLayout.vue'

const props = defineProps({
  hospitals: {
    type: Array,
    required: true
  },
  errors: {
    type: Object,
    default: () => ({})
  }
})

const form = ref({
  name: '',
  specialty: '',
  bio: '',
  hospital_id: '',
  is_active: true,
  image: null,
  image_preview: null
})

const handleImageChange = (event) => {
  const file = event.target.files[0]
  if (file) {
    form.value.image = file
    const reader = new FileReader()
    reader.onload = (e) => {
      form.value.image_preview = e.target.result
    }
    reader.readAsDataURL(file)
  }
}

const submit = () => {
  const formData = new FormData()
  formData.append('name', form.value.name)
  formData.append('specialty', form.value.specialty)
  formData.append('bio', form.value.bio)
  formData.append('hospital_id', form.value.hospital_id)
  formData.append('is_active', form.value.is_active ? '1' : '0')
  if (form.value.image) {
    formData.append('image', form.value.image)
  }

  router.post(route('admin.doctors.store'), formData, {
    onSuccess: () => {
      router.visit(route('admin.doctors.index'))
    },
    onError: (errors) => {
      console.error(errors)
    }
  })
}
</script>
