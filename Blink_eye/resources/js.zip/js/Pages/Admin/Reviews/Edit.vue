<template>
  <div class="max-w-3xl mx-auto py-6 sm:px-6 lg:px-8">
    <div class="px-4 py-6 sm:px-0">
      <div class="mb-6">
        <h1 class="text-2xl font-semibold text-gray-900">Edit Review</h1>
        <p class="mt-1 text-sm text-gray-600">Update patient review or testimonial</p>
      </div>

      <div class="bg-white shadow-sm rounded-lg p-6">
        <form @submit.prevent="submit">
          <div class="space-y-6">
            <div>
              <label for="author_name" class="block text-sm font-medium text-gray-700 mb-2">
                Author Name *
              </label>
              <input
                v-model="form.author_name"
                type="text"
                id="author_name"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter author name"
                required
              />
              <div v-if="errors.author_name" class="mt-1 text-sm text-red-600">{{ errors.author_name[0] }}</div>
            </div>

            <div>
              <label for="rating" class="block text-sm font-medium text-gray-700 mb-2">
                Rating *
              </label>
              <select
                v-model="form.rating"
                id="rating"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Select rating</option>
                <option :value="1">1 Star</option>
                <option :value="2">2 Stars</option>
                <option :value="3">3 Stars</option>
                <option :value="4">4 Stars</option>
                <option :value="5">5 Stars</option>
              </select>
              <div v-if="errors.rating" class="mt-1 text-sm text-red-600">{{ errors.rating[0] }}</div>
            </div>

            <div>
              <label for="source" class="block text-sm font-medium text-gray-700 mb-2">
                Source *
              </label>
              <select
                v-model="form.source"
                id="source"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Select source</option>
                <option value="internal">Internal</option>
                <option value="google">Google</option>
                <option value="healthgrades">Healthgrades</option>
                <option value="facebook">Facebook</option>
                <option value="yelp">Yelp</option>
              </select>
              <div v-if="errors.source" class="mt-1 text-sm text-red-600">{{ errors.source[0] }}</div>
            </div>

            <div>
              <label for="content" class="block text-sm font-medium text-gray-700 mb-2">
                Review Content
              </label>
              <textarea
                v-model="form.content"
                id="content"
                rows="4"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter review content"
              ></textarea>
              <div v-if="errors.content" class="mt-1 text-sm text-red-600">{{ errors.content[0] }}</div>
            </div>
          </div>

          <div class="mt-6 flex items-center justify-end space-x-3">
            <Link :href="route('admin.reviews.index')" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors">
              Cancel
            </Link>
            <button
              type="submit"
              :disabled="processing"
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              <span v-if="processing">Updating...</span>
              <span v-else>Update Review</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Head, Link, useForm } from '@inertiajs/vue3'

defineProps({
  review: Object,
})

const form = useForm({
  author_name: '',
  rating: '',
  content: '',
  source: 'internal',
})

const errors = ref({})
const processing = ref(false)

// Initialize form with existing data
form.author_name = review.author_name
form.rating = review.rating
form.content = review.content
form.source = review.source

const submit = () => {
  processing.value = true
  errors.value = {}

  form.put(route('admin.reviews.update', review.id), {
    onSuccess: () => {
      processing.value = false
    },
    onError: (err) => {
      processing.value = false
      errors.value = err
    },
  })
}
</script>
